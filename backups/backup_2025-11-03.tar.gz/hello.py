name = input("Enter your name: ")
name = "Harsha"
env = "dev"
print("Hello",name)