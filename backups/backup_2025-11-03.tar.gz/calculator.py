num1 = int(input("Enter first number: "))  #string input -> int Type casting
num2 = int(input("Enter second number: ")) #string input -> int Type casting

print(type(num1))
print(type(num2))

sum_of_num = num1 + num2

print("The sum is:", sum_of_num)

diff_of_num = num1 - num2

print("The difference is:", diff_of_num)

prod_of_num = num1 * num2

print("The sum is:", prod_of_num)

div_of_num = num1 / num2

print("The difference is:", div_of_num)